package com.uty.listviewicon.model

class Pirate {
    var name: String = ""
    var detail:String = ""
    var poster: Int = 0

}