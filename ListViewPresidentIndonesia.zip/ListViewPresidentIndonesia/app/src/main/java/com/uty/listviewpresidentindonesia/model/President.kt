package com.uty.listviewpresidentindonesia.model

class President {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}